bl_info = {
    "name": "Import-Export: 3D Modeling App File (.3ma)",
    "blender": (3, 6, 0),
    "category": "Import-Export",
}

import bpy
import os
import json
from bpy_extras.io_utils import ImportHelper

# Replace this with your actual .3ma import function
def import_3ma(input_filee):
    # Rename the .3ma file to .json
    new_file_path = input_filee.replace(".3ma",".json")
    os.rename(input_filee, new_file_path)
    
    # Clear mesh objects in the scene
    '''
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_by_type(type='MESH')
    bpy.ops.object.delete()
    '''
    
    
    # Load JSON data from the renamed file
    with open(new_file_path, "r") as f:
        data = json.load(f)
    
    #vertices = data["vertices"]
    #faces = data["faces"]
    
    meshes = data["meshes"]
    mesh_num = len(meshes)
    
    vertices = []
    faces = []
    
    vertices_permesh = []
    faces_permesh = []
    
    temp_fc = []
    
    os.rename(new_file_path, input_filee)
    
    for msh in range(mesh_num): # for every mesh in the dictionary meshes
        preciseFactor = meshes[msh]["preciseFactor"]
        for vtx in range(0,len(meshes[msh]["_positions"]),3):
            _pos_0 = meshes[msh]["_positions"][vtx]/preciseFactor 
            _pos_1 = meshes[msh]["_positions"][vtx+1]/preciseFactor 
            _pos_2 = (meshes[msh]["_positions"][vtx+2]*-1)/preciseFactor 
            vertices.append((_pos_0,_pos_1,_pos_2))
        
        vertices_permesh.append(vertices)
        vertices=[]
        
        UnivertsList = meshes[msh]["facesUnivertsList"]
        for fcx in UnivertsList: # looping thru the items in order, which are dictionaries
            for fcx_ndx in fcx["u"]: # looping inside the current dictionary
                temp_fc.append(fcx_ndx)
            faces.append(tuple(temp_fc))  
            temp_fc = []  
        
        faces_permesh.append(faces)
        faces=[]
    
    
        # Create new mesh and link it to scene
        mesh = bpy.data.meshes.new(name="New_Object_Mesh "+str(msh))
        obj = bpy.data.objects.new("New_Object "+str(msh), mesh)
    
        bpy.context.collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
    
        # Construct the mesh
        mesh.from_pydata(vertices_permesh[msh], [], faces_permesh[msh])
        mesh.update()
    

# Operator to show the file selector
class SimpleOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "object.simple_operator"
    bl_label = "Import .3ma File"
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        input_file = self.properties.filepath 
        # Run your custom import function
        
        #self.report({'INFO'}, input_file)
        import_3ma(input_file)

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# Panel to activate the file selector
class SimpleOperatorPanel(bpy.types.Panel):
    bl_label = "Import .3ma File"
    bl_idname = "OBJECT_PT_simple_operator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("object.simple_operator")

# Register classes and operators
def register():
    bpy.utils.register_class(SimpleOperator)
    bpy.utils.register_class(SimpleOperatorPanel)

def unregister():
    bpy.utils.unregister_class(SimpleOperator)
    bpy.utils.unregister_class(SimpleOperatorPanel)

if __name__ == "__main__":
    register()
    
    
    
    
    
    
